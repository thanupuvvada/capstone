### Here is the project click and Download ➡️ [03-Supervised Machine Learning Classification.pdf](https://github.com/iamvikramkumar/ibm_machine_learning_coursera/files/13214925/03-Supervised.Machine.Learning.Classification.pdf)
# NOTE:
## Please make some minor changes to the project. I have mentioned my name in it, so you should remove it before uploading. Thank you.
