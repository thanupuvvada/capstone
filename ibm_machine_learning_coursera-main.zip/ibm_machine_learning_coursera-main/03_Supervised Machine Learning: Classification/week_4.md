# WEEK 4 QUIZ

## Q1. These are all characteristics of decision trees, EXCEPT:
`They have well rounded decision boundaries`

## Q2. Decision trees used as classifiers compute the value assigned to a leaf by calculating the ratio: number of observations of one class divided by the number of observations in that leaf E.g. number of customers that are younger than 50 years old divided by the total number of customers.
## How are leaf values calculated for regression decision trees?
`average value of the predicted variable`

## Q3. These are two main advantages of decision trees:
`They are very visual and easy to interpret`

## Q4. How can you determine the split for each node of a decision tree? 
`Find the split that minimizes the gini impurity.` 

## Q5. Which of the following describes a way to regularize a decision tree to address overfitting?
`Decrease the max depth.`

## Q6. What is a disadvantage of decision trees?
`They tend to overfit.`

## Q7. What method can you use to minimize overfitting of a machine learning model?
`Tune the hyperparameters of your model using cross-validation.`

## Q8. Concerning Classification algorithms, what is a characteristic of K-Nearest Neighbors?

`Training data is the model`

## Q9. Concerning Classification algorithms, what are the characteristics of Logistic Regression?
`The model is just parameters, fitting can be slow, prediction is fast, and the decision boundary is simple and less flexible`

## Q10. When evaluating all possible splits of a decision tree what can be used to find the best split regardless of what happened in prior or future steps?
`Greedy Search`
