# WEEK 2 QUIZ

## Q1. Which one of the following statements is true regarding K Nearest Neighbors?
`K Nearest Neighbors (KNN) assumes that points which are close together are similar.`


## Q2. Which one of the following statements is most accurate? 
`K nearest neighbors (KNN) needs to remember the entire training dataset in order to classify a new data sample.` 

## Q3. Which one of the following statements is most accurate about K Nearest Neighbors (KNN)? 
`KNN can be used for both classification and regression.`

## Q4. (True/False) K Nearest Neighbors with large k tend to be the best classifiers.
`False`

## Q5. When building a KNN classifier for a variable with 2 classes, it is advantageous to set the neighbor count k to an odd number.
`True`

## Q6. The Euclidean distance between two points will always be shorter than the Manhattan distance:
`True`

## Q7. The main purpose of scaling features before fitting a k nearest neighbor model is to:
  `Ensure that features have similar influence on the distance calculation`

## Q8. These are all pros of the k nearest neighbor algorithm EXCEPT:
  ` It is sensitive to the curse of dimensionality`
