# WEEK 7 QUIZ

## Q1. Select the correct option:

Statement 1: Autoencoders are a supervised learning technique.

Statement 2: Autoencoder’s output is exactly the same as the input.

`Both statements are false.`


## Q2. Select the correct option: 

Statement 1: Autoencoders can be viewed as a generalization of PCA that discovers lower dimensional representation of complex data.

Statement 2: We can implement overcomplete autoencoder by constraining the number of units present in the hidden layers of the neural network.

`Statement 1 is true, statement 2 is false.`

## Q3. (True/False) Denoising autoencoders can be used as a tool for feature extraction.

`True`


## Q4. (True/False) An Autoencoder is a form of unsupervised deep learning.

`True`
