# WEEK 3 QUIZ

## Q1. What is the main function of backpropagation when training a Neural Network?

`Make adjustments to the weights`

## Q2. (True/False) The “vanishing gradient” problem can be solved using a different activation function.
`True`
## Q3. (True/False) Every node in a neural network has an activation function.
`True`

## Q4. These are all activation functions except:
`Leaky hyperbolic tangent`

## Q5. Deep Learning uses deep Neural Networks for all these uses, except
`Cases in which explainability is the main objective`

## Q6. These are all activation functions except:
`Pruning`

## Q7. (True/False) Optimizer approaches for Deep Learning Regularization use gradient descent:
`False`

## Q8. Stochastic gradient descent is this type of batching method:

`online learning`

## Q9. (True/False) The main purpose of data shuffling during the training of a Neural Network is to aid convergence and use the data in a different order each epoch.

`True`

## Q10. This is a high-level library that is commonly used to train deep learning models and runs on either TensorFlow or Theano:
`Keras`
