# WEEK 2 QUIZ

## Q1. The backpropagation algorithm updates which of the following?
`The parameters only.`

## Q2. What of the following about the activation functions is true? 

`They add non-linearity into the model, allowing the model to learn complex pattern.` 

## Q3. What is true regarding the backpropagation rule? 
`The actual output is determined by computing the output of neurons in each hidden layer `

## Q4. Which option correctly lists the steps to build a linear regression model using Keras?
1. Use `fit()` and specify the number of epochs to train the model for.

2. Create a Sequential model with the relevant layers.

3. Normalize the features with ` layers.Normalization()` and apply `adapt()`.

4. Compile using `model.compile()` with specified optimizer and loss.

ANSWER ➡️ `3, 2, 4, 1`

## Q5. (True/False) Keras provides one approach to build a model: by defining a Sequential model. 
`False`
