### Here is the project click and Download ➡️ [05-Deep Learning and Reinforcement Learning.pdf](https://github.com/iamvikramkumar/ibm_machine_learning_coursera/files/13214748/05-Deep.Learning.and.Reinforcement.Learning.pdf)

# NOTE:
## Please make some minor changes to the project. I have mentioned my name in it, so you should remove it before uploading. Thank you.
