# WEEK 4 QUIZ

## Q1. What is the main function of backpropagation when training a Neural Network?
`Make adjustments to the weights`

## Q2. What is the main function of backpropagation when training a Neural Network?
(True/False) The “vanishing gradient” problem can be solved using a different activation function.
`True`

## Q3. What is the main function of backpropagation when training a Neural Network?
(True/False) Every node in a neural network has an activation function.

`True`

## Q4. What is the main function of backpropagation when training a Neural Network? These are all activation functions except:
- [ ] Sigmoid
- [ ] Hyperbolic tangent
- [X] Leaky hyperbolic tangent
- [ ] ReLu

## Q5. Deep Learning uses deep Neural Networks for all these uses, except:
`Cases in which explainability is the main objective`

## Q6. These are all activation functions for CNN, except:
`Pruning`

## Q7. (True/False) Optimizer approaches for Deep Learning Regularization use gradient descent:
`False`

## Q8. Stochastic gradient descent is this type of batching method:

`online learning`

## Q9. The main purpose of data shuffling during the training of a Neural Network is to aid convergence and use the data in a different order each epoch.
`True`

## Q10. Which of the following IS NOT a benefit of Transfer Learning?
`Improving the speed at which large models can be trained from scratch`

## Q11. Which of the following statements about using a Pooling Layer is TRUE?

`Pooling can reduce both computational complexity and overfitting.`
