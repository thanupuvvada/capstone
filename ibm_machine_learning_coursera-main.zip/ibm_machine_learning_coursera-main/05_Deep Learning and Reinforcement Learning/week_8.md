# WEEK 8 QUIZ

## Q1. Select the right assertion:

`Autoencoders learn from a compressed representation of the data, while variational autoencoders learn from a probability distribution representing the data.`

## Q2. (True/False) Variational autoencoders are generative models.

`True`

## Q3. When comparing the results of Autoencoders and Principal Component Analysis, which approach might best improve the results from Autoencoders?
`Add layers and epochs`

## Q4. (True/False) KL loss is used in Variatoinal Autoencoders to represent the measure of the difference between two distributions.

`True`

## Q5. A good way to compare the inputs and outputs of a Variational Autoencoder is to calculate the mean of a reconstruction function based on binary crossentropy.

`True`


## Q6. The main parts of GANs architecture are:

`generator and discriminator`


## Q7. (True/False) One of the main advantages of GANs over other adversarial networks is that it does not spend any time evaluating whether an input or image is fake or real. It only computes probability of being fake.
`True`
