# WEEK 9 QUIZ

## Q1. (True/False) Simulation is a common approach for Reinforcement Learning applications that are complex or computing intensive.
`True`

## Q2.(True/False) Discounting rewards refers to an agent reducing the value of the reward based on its uncertainty.
`False`

## Q3. (True/False) Successful Reinforcement Learning approaches are often limited by extreme sensitivity to hyperparameters.
`True`

## Q4. (True/False) Reinforcement Learning approaches are often limited by excessive computation resources and data requirements.
`True`

## Q5. Which type of Deep Learning approach is most commonly used for image recognition?
`Convolutional Neural Network`


## Q6. Which type of Deep Learning approach is most commonly used for forecasting problems?

`Recurrent Neural Network`

## Q7. Which type of Deep Learning approach is most commonly used for generating artificial images?

`Autoencoders`

