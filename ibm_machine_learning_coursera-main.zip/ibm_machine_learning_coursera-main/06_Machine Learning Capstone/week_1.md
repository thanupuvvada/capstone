# WEEK 1
## 📜 Introduction Part 📜 
## There is no any task move forward for next week.
HAPPY LEARNING 😊

