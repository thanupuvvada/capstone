# WEEK 6 
## Week 6 is Project work and the ball is in your court or may be it updated in future.
🌟 HAPPY LEARNING! 😊📚

### Here is the project click and Download ➡️
[Machine Learning Capstone.pdf](https://github.com/iamvikramkumar/ibm_machine_learning_coursera/files/13214662/06_Machine.Learning.Capstone.pdf)

# NOTE:
## Please make some minor changes to the project. I have mentioned my name in it, so you should remove it before uploading. Thank you.
