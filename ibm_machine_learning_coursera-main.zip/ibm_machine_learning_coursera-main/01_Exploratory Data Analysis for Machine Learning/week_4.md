
## Q1. Which one of the following is common to both machine learning and statistical inference? ⬇️⬇️
Using sample data to infer qualities of the underlying population distribution.

## Q2. Which one of the following describes an approach to customer churn prediction stated in terms of probability?
Predicting a score for individuals that estimates the probability the customer will leave.

## Q3. What is customer lifetime value?
The total purchases over the time which the person is a customer.

## Q4. Which one the following statements about the normalized histogram of a variable is true?
It provides an estimate of the variable’s probability distribution. 

## Q5. The outcome of rolling a fair die can be modelled as a _______ distribution.
uniform

## Q6. Which one of the following features best distinguishes the Bayesian approach to statistics from the Frequentist approach?
Bayesian statistics incorporate the probability of the hypothesis being true.

## Q7. Which of the following best describes what a hypothesis is
A hypothesis is a statement about a population.

## Q8. A Type 2 error in hypothesis testing is _____________________:
incorrectly accepting the null hypothesis.

## Q9. Which statement best describes a consequence of a type II error in the context of a churn prediction example? Assume that the null hypothesis is that customer churn is due to chance, and that the alternative hypothesis is that customers enrolled for greater than two years will not churn over the next year. 
You incorrectly conclude that customer churn is by chance

## Q10. Which of the following is a statistic used for hypothesis testing?
The likelihood ratio.

