# WEEK 2 QUIZ

## Q1. What is the other name we can give to the L2 distance?
`Euclidean Distance` 

## Q2. Which of the following statements is a business case for the use of the Manhattan distance (L1)?
`We use it in business cases where there is very high dimensionality.` 

## Q3. What is the key feature for the Cosine Distance?
`The Cosine Distance, which takes into acount the angle between 2 points.`

## Q4. The following statement is an example of a business case where we can use the Cosine Distance?

`Cosine is better for data such as text where location of occurrence is less important. `


## Q5. Which distance metric is useful when we have text documents and we want to group similar topics together?

`Jaccard `
