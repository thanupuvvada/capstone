# WEEK 1 QUIZ 

## Q1. What is the implication of a small standard deviation of the clusters?
`The standard deviation of the cluster defines how tightly around each one of the centroids are. With a small standard deviation, the points will be closer to the centroids. `

## Q2. After we plot our elbow and we find the inflection point, what does that point indicate to us?

`The ideal number of clusters. `

## Q3. What is one of the most suitable ways to choose K when the number of clusters is unclear? 

`By evaluating Clustering performance such as Inertia and Distortion.`

## Q4. Which statement describes correctly the use of distortion and inertia?

`When the similarity of the points in the cluster are more important, you should use distortion, and if you are more concerned that clusters have similar numbers of points, then you should use inertia.` 


## Q5. Which method is commonly used to select the right number of clusters? 

`The elbow method.`
