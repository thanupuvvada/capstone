# WEEK 5 QUIZ

## Q1. What is the main difference between kernel PCA and linear PCA?
`Kernel PCA tend to uncover non-linearity structure within the dataset by increasing the dimensionality of the space thanks to the kernel trick.`

## Q2. (True/False) Multi-Dimensional Scaling (MDS) focuses on maintaining the geometric distances between points
`True`

## Q3. Which of the following data types is more suitable for Kernel PCA than PCA?
`Data where the classes are not linearly separable.`

## Q4. By applying MDS, you are able to:
`Find embeddings for points so that their distance is the most similar to the original distance.`

## Q5. Which one of the following hyperparameters is NOT considered when using GridSearchCV for Kernel PCA?
`n_clusters`

