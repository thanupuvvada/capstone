# WEEK 4 QUIZ  
## Q1. Which of the following statements about model complexity is TRUE? 
   - Higher model complexity leads to a higher chance of overfitting. 

## Q2.Which of the following statements about model errors is TRUE? 
 - Underfitting is characterized by higher errors in both training and test samples. 

## Q3. Which of the following statements about regularization is TRUE? 
 - Regularization decreases the likelihood of overfitting relative to training data.

## Q4. Which of the following statements about scaling features prior to regularization is TRUE?
- The larger a feature’s scale, the more likely its estimated impact will be influenced by regularization.

## Q5. Which one of the 3 Regularization techniques: Ridge, Lasso, and Elastic Net, performs the fastest under the hood? 
- Ridge

## Q6. Which of the following statements about Elastic Net regression is TRUE?
-  Elastic Net combines L1 and L2 regularization. 

## Q7. BOTH Ridge regression and Lasso regression 
- Add a term to the loss function proportional to a regularization parameter.


## Q8. Compared with Lasso regression (assuming similar implementation), Ridge regression is: 
- Less likely to set feature coefficients to zero.  

## Q9. Which of the following about Ridge Regularization is TRUE?
- It enforces the coefficients to be lower, but not 0
- It minimizes irrelevant features 
- It penalizes the size  magnitude of the regression coefficients by adding a squared term 
-  ANSWER ➡️ `All of the above`


## Q10. Whixh of the below statements are correct?
- Only LassoCV use L1 regularization function.
