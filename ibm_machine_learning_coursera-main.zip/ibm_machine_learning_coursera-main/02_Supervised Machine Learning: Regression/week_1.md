
# WEEK 1 QUIZ
## Q1. You can use supervised machine learning for all of the following examples, EXCEPT:
 Segment customers by their demographics.

## Q2. The autocorrect on your phone is an example of:
Supervised learning

## Q3. Which of the following is the type of Machine Learning that uses only data with outcomes to build a model? 
Supervised Machine Learning

## Q4. Which among the following options does not conform to the best practice of modelling in Supervised Machine learning?   
Develop multiple models.

## Q5. This is the syntax you need to predict new data after you have trained a linear regression model called LR :
LR.predict(X_test)

## Q6. All of these options are useful error measures to compare regressions except:
ROC index

## Q7. All of the listed below are part of the Machine Learning Framework, except:

Observations
Features
Parameters
Answer ➡️ None of the above 

## Q8. Select the option that is the most INACCURATE regarding the definition of Machine Learning:
Machine Learning is automated and requires no programming

## Q9. In Linear Regression, which statement is correct about Sum Squared Error?
The Sum Squared Error measures the distance between the truth and predicted values.

## Q10. When learning about regression we saw the outcome as a continuous number. Given the below options what is an example of regression?
Housing prices
